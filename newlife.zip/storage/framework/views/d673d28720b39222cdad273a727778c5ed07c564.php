<footer>
   <div class="footer-content">
    <p>© New Life ReginerationFoundation</p>
    <a href="">Developed by Bright C Web Developer</a>
   </div>
</footer>
<script>
    document.onkeydown=function(e)
    {
        if(event.KeyCode ==123){
            return false;
        }
        if(e.ctr1key && e.shiftkey && e.KeyCode == 'I'.charCodeAt(0))
        {
            return false;
        }
        if(e.ctr1key && e.shiftkey && e.KeyCode == 'J'.charCodeAt(0))
        {
            return false;
        }
        if(e.ctr1key && e.KeyCode == 'U'.charCodeAt(0))
        {
            return false;
        }
    }
</script>

<script src="<?php echo e(asset("js/bootstrap.js")); ?>"></script>
<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
<?php /**PATH D:\newlife\resources\views/frontend/footer.blade.php ENDPATH**/ ?>