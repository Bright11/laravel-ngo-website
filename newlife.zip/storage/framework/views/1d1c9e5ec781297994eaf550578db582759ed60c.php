
<?php $__env->startPush('icon'); ?>
<link rel="stylesheet" href="<?php echo e(asset("css/indexcss.css")); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="blogpage">
  <div class="blogcategory-holder">
    <ul class="blogcatul">
      <?php $__empty_1 = true; $__currentLoopData = $blogcat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <li><a href="/getblogcat/<?php echo e($c->id); ?>"><?php echo e($c->title); ?></a></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          
      <?php endif; ?>
      
    </ul>
  </div>
  <div class="blogcontent-holder">
    <div class="blog-holder">
      <?php $__empty_1 = true; $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="blog-img">
        <a href="/blogdetails/<?php echo e($b->id); ?>">
        <img src="<?php echo e(asset('blog/'.$b->image)); ?>" alt="<?php echo e($b->blogtitle); ?>"/>
        
        <div class="blog-info">
         <h1> <?php echo e($b->blogtitle); ?></h1>
          <p><?php echo Str::limit($b->bloginfo,50,$end=""); ?><a href='/blogdetails/<?php echo e($b->id); ?>' class='readmore'> Read More...</a></p>

        </div>
      </a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views/frontend/ourblog.blade.php ENDPATH**/ ?>