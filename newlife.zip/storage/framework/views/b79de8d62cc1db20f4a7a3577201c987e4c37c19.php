

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="admin--content-dashboard">
  
    <?php echo $__env->make('admin.adminsidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin-main-content">
        <div class="blogform-flex">
        <li><a href="/sitedescription">Add site description</a></li>
        <li><a href="/sitekeywords">Add site keywords</a></li>
    </div>
        <div class="event-table">
            <table class="table">
                <thead >
                  <tr >
                  
                    <th scope="col">Name</th>
                    
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody >
                  
                  
                  
                </tbody>
              </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views/admin/seosettings.blade.php ENDPATH**/ ?>