
<?php $__env->startPush('icon'); ?>
<link rel="stylesheet" href="<?php echo e(asset("css/indexcss.css")); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="details-page">
  <div class="details-name">
    <img src="<?php echo e(asset("event/" .$seeevent->event_img)); ?>" alt="<?php echo e($seeevent->event_name); ?>"/>
    <h1><?php echo e($seeevent->event_name); ?></h1>
    
  </div>
   <div class="eventinfo">
    <p>Location &nbsp;<?php echo $seeevent->event_location; ?></p>
    <div class="event-date">
    <p>Event Date &nbsp;<?php echo e($seeevent->event_date); ?></p>
    <p>Event Time&nbsp;<?php echo e($seeevent->event_time); ?>&nbsp;<?php echo e($seeevent->settime); ?></p>

    </div>
    <p><?php echo $seeevent->event_info; ?></p>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views\frontend\viewevent.blade.php ENDPATH**/ ?>