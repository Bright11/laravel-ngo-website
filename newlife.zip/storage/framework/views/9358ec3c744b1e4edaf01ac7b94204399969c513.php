<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="admin--content-dashboard">

    <?php echo $__env->make('admin.adminsidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin-main-content">

       <div class="blogform-flex">

        <li><a href="/admin_videos">Back to Videos</a></li>

       </div>

            <form class="formadmin" action="/insertvideo" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label>Video title</label>
                <input type="text" placeholder="Video title" name="title">

                <label>Video Link</label>
                <input type="text" name="video">

                <button>Save</button>
            </form>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/35.2.1/classic/ckeditor.js"></script>
<script src="<?php echo e(asset("js/ckeditor.js")); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views/admin/admin_video_add.blade.php ENDPATH**/ ?>