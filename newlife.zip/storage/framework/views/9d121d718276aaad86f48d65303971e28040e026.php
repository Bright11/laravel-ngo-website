
<?php $__env->startPush('icon'); ?>
<link rel="stylesheet" href="<?php echo e(asset("css/indexcss.css")); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="<?php echo e(asset("/owl/owl.carousel.min.css")); ?>">
<link rel="stylesheet" href="<?php echo e(asset("/owl/owl.theme.default.min.css")); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<section class="top-slider">
  <div class="mytopslide">
    <?php echo $__env->make('frontend.top_slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
</section>
<h1 class="causesh1">Our <u class="h1color">Causes</u></h1>
  <div class="ourcause-holder">
    
    <div class="ourcauses-content">
    <div class="ourcauses-content-holder">
        <?php $__empty_1 = true; $__currentLoopData = $causestable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ourc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="our-cause-rows">
              <div class="cuasusimg">
                <img src="<?php echo e(asset("causeimg/" .$ourc->image)); ?>" alt="<?php echo e($ourc->name); ?>"/>
              </div>
                <h1><?php echo e($ourc->name); ?></h1>
           
             <p><?php echo Str::limit($ourc->description,50,$end=""); ?><a href='/details/<?php echo e($ourc->id); ?>' class='readmore'> Read More...</a></p>
           
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h1>Not found</h1>
        <?php endif; ?>
    </div>
  </div>
  <section class="event-section">
  
     
<div class="event-details">
  <div class="newevent-holder">
    <h4>Latest Event</h4>
  <div class="newevent">
   
      <?php $__empty_1 = true; $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
         <a href="/viewevent/<?php echo e($e->id); ?>" class="eventlink">
          <div class="newevents">
            <img src="<?php echo e(asset('event/'.$e->event_img)); ?>" alt=""/>
            <div class="eventinfo">
              <p><?php echo e($e->event_name); ?></p>
            
              <div class="eventinfodate">
              <p><?php echo e($e->event_date); ?> &nbsp;</p>
              <p><?php echo e($e->event_time); ?> <?php echo e($e->settime); ?></p>
            </div>
          </div>
       
          </div>
         </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <?php endif; ?>
  </div>
</div>
  <div class="passevent">
    <h4>All enevts</h4>
    <div class="mywol-container">
      <div class="eventslid owl-carousel owl-theme">
        <?php $__empty_1 = true; $__currentLoopData = $allevent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="owlitemindex">
        
          <img src="<?php echo e(asset('event/'.$e->event_img)); ?>" alt=""/>
         
           
          
            <div class="owlitemindex-details">
              <p><?php echo e($e->event_name); ?></p>
            
            <p><?php echo e($e->event_date); ?> &nbsp;<?php echo e($e->event_time); ?> <?php echo e($e->settime); ?></p>
          </div>
  
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php endif; ?>
        
    </div>
    </div>
  </div>
  <div class="donet" style="background-image: url(<?php echo e(asset("logo/logo.jpeg")); ?>)">
    <h4>Your help will help to limit crime</h4>
    <form>
      <label>Name <small>Optional</small></label>
      <input type="text" placeholder="Your Name "/>
      <label>Donate for</label>
      <input type="text" placeholder="Donating for"/>
      <label>Amount</label>
      <input type="number" placeholder="Amount to Donate"/>
      <button>Donate</button>
    </form>
  </div>
</div>
  </section>
  <section class="voluteers">

    

  
      <h3>Our Gallery</h3>
    <div class="gallery-slide owl-carousel">
      <?php $__empty_1 = true; $__currentLoopData = $getgallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="mysponsor">
            
            <img src="<?php echo e(asset('gallery/'.$s->image)); ?>" alt="<?php echo e($s->title); ?>"/>
            <div class="company-name">
           <h1 class="galleryh1"> <?php echo e($s->title); ?></h1>
            </div>
        
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          
      <?php endif; ?>
   
    </div>
   <div class="view-all-gallery">
    <a href="/ourgallery">View all gallery</a>
   </div>
    <h3>Our Sponsors</h3>
    <div class="voluteers-slide owl-carousel">
      <?php $__empty_1 = true; $__currentLoopData = $sponsor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="mysponsor">
            <a href="<?php echo e($s->company_website); ?>">
            <img src="<?php echo e(asset('sponsor/'.$s->company_logo)); ?>" alt="<?php echo e($s->company_name); ?>"/>
            <div class="company-name">
           <h1> <?php echo e($s->company_name); ?></h1>
            </div>
          </a>
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          
      <?php endif; ?>
    
    </div>

  </section>

  <?php echo $__env->make('frontend.pay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo e($checkexist->usercode); ?>

  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset("js/jquery.js")); ?>"></script>
<script src="<?php echo e(asset("owl/owl.carousel.min.js")); ?>"></script>
<script src="<?php echo e(asset("owl/myowl.js")); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views\frontend\index.blade.php ENDPATH**/ ?>