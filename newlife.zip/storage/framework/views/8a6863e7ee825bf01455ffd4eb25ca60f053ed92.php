<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>New Life Regineration Foundation <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->yieldPushContent('icon'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/bootstrap.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/frontend.css")); ?>">

    <meta name="description"
        content="New Life Regeneration Foundation is a nonprofit organization focusing on youth who are into drugs and other activities which may be harmful to their body">
    <meta name="keywords"
        content="Agriculture,nonprofit,
Nonprofit, for women,
Social justice, nonprofit organizations,
Health and fitness,organizations,
Eco-friendly,Nonprofit organizations near me
Local nonprofits near me,
Top nonprofits in Africa,Charity‌,charity‌
Best nonprofits in Ghana">
    <meta name="author" content="New Life Regeneration Foundation">

</head>

    <body>
    <?php echo $__env->make('frontend.topnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\newlife\resources\views/frontend/master.blade.php ENDPATH**/ ?>