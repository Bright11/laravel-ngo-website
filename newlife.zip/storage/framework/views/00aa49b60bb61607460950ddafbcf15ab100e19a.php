<?php $__env->startPush('icon'); ?>
<link rel="stylesheet" href="<?php echo e(asset("css/indexcss.css")); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .notfound {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            margin: 50px 0px;
        }
        .notfound a{
            text-decoration: none;
            background-color: #F26522;
            color: white;
            font-size: 20px;
            font-weight: 600;
            padding: 20px;
        }
    </style>
    <div class="notfound">
        <h1>404 NOT FOUND</h1>
        <a href="">Back to the site</a>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views/errors/404.blade.php ENDPATH**/ ?>