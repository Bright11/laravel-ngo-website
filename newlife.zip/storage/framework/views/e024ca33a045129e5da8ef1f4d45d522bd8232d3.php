
<?php echo $__env->yieldPushContent('custom-scripts'); ?>   
</body>
</html><?php /**PATH D:\newlife\resources\views/admin/adminfooter.blade.php ENDPATH**/ ?>