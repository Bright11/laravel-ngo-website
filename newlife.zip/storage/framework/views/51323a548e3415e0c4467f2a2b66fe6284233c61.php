

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="admin--content-dashboard">
  
    <?php echo $__env->make('admin.adminsidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin-main-content">
        <li><a href="/addsponsorform">Add Sponsorship</a></li>
        <div class="event-table">
            <table class="table">
                <thead>
                  <tr>
                   
                    <th scope="col">Company Name</th>
                    <th scope="col">Location</th>
                    <th scope="col">Logo</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $seesponsor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                    
                    <td><?php echo e($s->company_name); ?></td>
                    <td><?php echo e($s->company_location); ?></td>
                    <td><img src="<?php echo e(asset("sponsor/" .$s->company_logo)); ?>" alt="<?php echo e($s->company_name); ?>"/></td>
                    <td><a href="/deletcompany/<?php echo e($s->id); ?>" class="admin-delete">Delete</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      
                  <?php endif; ?>
                  
                  
                </tbody>
              </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views\admin\sponsors.blade.php ENDPATH**/ ?>