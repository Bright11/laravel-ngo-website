<?php $__env->startPush('icon'); ?>
<link rel="stylesheet" href="<?php echo e(asset("css/indexcss.css")); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="<?php echo e(asset(" /owl/owl.carousel.min.css")); ?>">
<link rel="stylesheet" href="<?php echo e(asset(" /owl/owl.theme.default.min.css")); ?>">
<link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<div class="container videocontainer mt-5 mb-5">
    <div class="row ml-5">

        <?php $__empty_1 = true; $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-6 col-md-4 video-row mb-5">
                <div class="vidoe-holderplayer">
                    <?php echo $v->video; ?>

                </div>
                <h1><?php echo e($v->title); ?></h1>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views/frontend/event_videos.blade.php ENDPATH**/ ?>