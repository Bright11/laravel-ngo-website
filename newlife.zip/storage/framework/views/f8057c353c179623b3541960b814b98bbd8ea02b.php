<div class="adminheader">
    <ul>
        <li><a href="">Admin</a></li>
       
        <?php if(session('status')): ?>
  
    
      <li ><a href="" style="color: red">  <?php echo e(session('status')); ?></a></li>
  
        <?php endif; ?>
    </ul>
</div><?php /**PATH D:\newlife\resources\views\admin\adminheader.blade.php ENDPATH**/ ?>