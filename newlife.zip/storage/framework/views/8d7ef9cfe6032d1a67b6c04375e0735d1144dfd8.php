<div class="owl-carousel topslider owl-theme" >
    <?php $__empty_1 = true; $__currentLoopData = $allevent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <div class="topslid-holder" >
    <img src="<?php echo e(asset('event/'.$e->event_img)); ?>" alt=""/>
   <div class="topslide-info">
    
    <?php if($e->event_date>$today): ?>
        <p>Latest Event</p>
        <p><?php echo e($e->event_name); ?></p>
        <p><?php echo e($e->event_date); ?> &nbsp;<?php echo e($e->event_time); ?> <?php echo e($e->settime); ?></p>
        <?php else: ?>
    <p>Pass Event</p>
    <p><?php echo e($e->event_name); ?></p>
    <?php endif; ?>
  <a href="/viewevent/<?php echo e($e->id); ?>">Read More...</a>
   </div>
  </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        
    <?php endif; ?>
    
</div><?php /**PATH D:\newlife\resources\views/frontend/top_slider.blade.php ENDPATH**/ ?>