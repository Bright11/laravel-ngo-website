

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="admin--content-dashboard">
  
    <?php echo $__env->make('admin.adminsidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin-main-content">
       
       <div class="blogform-flex">
        
        <li><a href="/blogtable">Back to Blog</a></li>
        <li><a href="/blogtable">Add Category</a></li>
       </div>
       
            <form class="formadmin" action="/insertblog" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label>Blog title</label>
                <input type="text" placeholder="Blog Tile" name="blogtitle">
                
                <label>Category</label>
                <select name="cat_id">
                    <option selected>Choose Category</option>
                    <?php $__empty_1 = true; $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($c->id); ?>"><?php echo e($c->title); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        
                    <?php endif; ?>

                </select>
                <label>Blog Image<small>Optional</small></label>
                <input type="file" name="image">
                <label>Blog Details</label>
                <textarea placeholder="Blog Information" name="bloginfo" id="bloginfo"></textarea>
                <button>Save</button>
            </form>
            
        </div>
    </div>
 
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/35.2.1/classic/ckeditor.js"></script>
<script src="<?php echo e(asset("js/ckeditor.js")); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views/admin/blogform.blade.php ENDPATH**/ ?>