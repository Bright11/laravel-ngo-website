

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="admin--content-dashboard">
  
    <?php echo $__env->make('admin.adminsidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin-main-content">
        <li><a href="/abouusform">Add About us</a></li>
        <div class="event-table">
            <table class="table">
                <thead>
                  <tr>
               
                    <th scope="col">Title</th>
                    <th scope="col">About us</th>
                    <th scope="col">Edit</th>
                    <th scope="col">Delete</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $about; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                    <th><?php echo e($ab->title); ?></th>
                    <td><?php echo $ab->about; ?></td>t
                    <td><a href="/editabout/<?php echo e($ab->id); ?>"class="admin-edit">Edit</a></td>
                    <td><a href="/deletabout/<?php echo e($ab->id); ?>"class="admin-delete">Delete</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      
                  <?php endif; ?>
                  
                  
                </tbody>
              </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views\admin\admin_aboutus.blade.php ENDPATH**/ ?>