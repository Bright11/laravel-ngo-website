<div class="topnav">
    <div class="topnav-item-holder">
        <div class="top-logo">
            <img src="<?php echo e(asset("logo/logo.jpeg")); ?>" alt="logo" />
        </div>
        <div class="topbaricon-holder">
            <a href="https://www.facebook.com/profile.php?id=100087493599356"><i class="fa fa-facebook-f topicons" title="Facebook" ></i></a>
            <a href=""><i class="fa fa-twitter-square topicons" title="Twitter" ></i></a>
           <a href=""> <i class="fa fa-youtube-play topicons" title="Youtube" ></i></a>
           <a href=""> <i class="fa fa-instagram topicons" title="Instagram" ></i></a>
        </div>

        <div class="topbarnumber-holder">

            <a href="tel:+233244834446" title="Call"> <i class="fa fa-phone topicons" ></i>+233244834446</a>
        </div>
    </div>
</div>

<style>
    .topbarnumber-holder a:hover{
color: white;
text-decoration: none;
    }
</style>
<?php /**PATH D:\newlife\resources\views/frontend/topnavbar.blade.php ENDPATH**/ ?>