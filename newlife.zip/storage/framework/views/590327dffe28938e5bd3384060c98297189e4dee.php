<footer>
   <div class="footer-content">
    <p>© New Life ReginerationFoundation</p>
    <a href="">Developed by Bright C Web Developer</a>
   </div>
</footer>

<script src="<?php echo e(asset("js/bootstrap.js")); ?>"></script>
<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html><?php /**PATH D:\newlife\resources\views\frontend\footer.blade.php ENDPATH**/ ?>