

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="admin--content-dashboard">
  
    <?php echo $__env->make('admin.adminsidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin-main-content">
       
       <div class="blogform-flex">
        
        <li><a href="/blogcategorytable">Back to Category</a></li>
        <li><a href="/blogtable">Add Blog</a></li>
       </div>
       
            <form class="formadmin" action="/addcategorytodb" method="post">
                <?php echo csrf_field(); ?>
                <label>Category title</label>
                <input type="text" placeholder="Category Tile" name="title">
                
                <button>Save</button>
            </form>
            
        </div>
    </div>
 
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/35.2.1/classic/ckeditor.js"></script>
<script src="<?php echo e(asset("js/ckeditor.js")); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views/admin/blogcategory.blade.php ENDPATH**/ ?>