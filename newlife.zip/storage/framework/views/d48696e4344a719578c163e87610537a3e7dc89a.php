

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="admin--content-dashboard">
  
    <?php echo $__env->make('admin.adminsidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin-main-content">
        <li><a href="/addeventform">Add Event</a></li>
        <div class="event-table">
            <table class="table">
                <thead>
                  <tr>
                    
                    <th scope="col">Event Name</th>
                    <th scope="col">Photo</th>
                    <th scope="col">Location</th>
                    <th scope="col">Date</th>
                    <th scope="col">Time</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $eventtable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                       
                        <td><?php echo e($e->event_name); ?></td>
                        <td> <img src="<?php echo e(asset('event/'.$e->event_img)); ?>" alt=""/></td>
                        <td><?php echo e($e->event_location); ?></td>
                        <td><?php echo e($e->event_date); ?></td>
                        <td><?php echo e($e->event_time); ?>&nbsp;<?php echo e($e->settime); ?></td>
                        <td><a href="/deleteevnt/<?php echo e($e->id); ?>" class="admin-delete">Delete</a></td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        
                    <?php endif; ?>
                  
                  
                </tbody>
              </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views\admin\addvent.blade.php ENDPATH**/ ?>