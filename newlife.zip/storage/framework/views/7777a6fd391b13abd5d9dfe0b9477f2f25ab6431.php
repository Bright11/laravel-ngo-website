

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="admin--content-dashboard">
  
    <?php echo $__env->make('admin.adminsidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin-main-content">
       
     
        <li><a href="/admingallery">Back To Gallery</a></li>
       
       
            <form class="formadmin" action="/insertgallery" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label> title</label>
                <input type="text" placeholder="Title" name="title">
                <label> Image</label>
                <input type="file" name="image">
                <button>Save</button>
            </form>
            
        </div>
    </div>
 
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/35.2.1/classic/ckeditor.js"></script>
<script src="<?php echo e(asset("js/ckeditor.js")); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views\admin\galleryform.blade.php ENDPATH**/ ?>