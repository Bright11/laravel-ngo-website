

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="admin--content-dashboard">
  
    <?php echo $__env->make('admin.adminsidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin-main-content">
        <li><a href="/ourcausesform">Add Causes</a></li>
        <div class="event-table">
            <table class="table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col"> Name</th>
                    <th scope="col">Image</th>
                   
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $ourc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <tr>
                    <th scope="row">1</th>
                    <td><?php echo e($c->name); ?></td>
                  
                    <td><img src="<?php echo e(asset("causeimg/" .$c->image)); ?>" alt="<?php echo e($c->name); ?>"/></td>
                    <td><a href="/deletcause/<?php echo e($c->id); ?>"class="admin-delete">Delete</a></td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      
                  <?php endif; ?>
                  
                  
                </tbody>
              </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views/admin/ourcauses.blade.php ENDPATH**/ ?>