<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="/">N.L.R.F</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        
          <ul class="navbar-nav " style="margin-left: auto">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="/">Home</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('ourblog')); ?>">Blog</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('ourgallery')); ?>">Gallery</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('event_videos')); ?>">Videos</a>
        </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('about')); ?>">About Us</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact Us</a>
          </li>
          <li class="nav-item" style="background-color: #F26522;border-radius:10px;">
            <a class="nav-link" href="<?php echo e(route('donation')); ?>" style="color:white;">Donate</a>
          </li>
          <?php if(Session::has('user')): ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Admin</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('logout')); ?>">Logout</a>
          </li>
          <?php else: ?>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('nlrfregister')); ?>">Register</a>
          </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('nlrflogin')); ?>">Login</a>
          </li>
          <?php endif; ?>
        </ul>

        
      </div>
    </div>
  </nav>
  <?php if(session('status')): ?>
  <div class="alert alert-success" role="alert">
    <h4><?php echo e(session('status')); ?></h4>
  </div>

  
  <?php elseif($errors->has('email')): ?>
  <div class="alert alert-success" role="alert">
    <h4>Check the imformation you provid</h4>
  </div>
  <?php elseif($errors->has('password')): ?>
  <div class="alert alert-success" role="alert">
    <h4>Check the imformation you provid</h4>
  </div>
  <?php elseif($errors->has('confirmpassword')): ?>
  <div class="alert alert-success" role="alert">
    <h4>Check the imformation you provid</h4>
  </div>
  <?php endif; ?>
<?php /**PATH D:\newlife\resources\views/frontend/navbar.blade.php ENDPATH**/ ?>