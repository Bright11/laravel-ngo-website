

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="admin--content-dashboard">
  
    <?php echo $__env->make('admin.adminsidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin-main-content">
       
       
            <li><a href="/addvent">Back to event</a></li>
       
            <form class="formadmin" action="/addeventtodb" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <label>Event Name</label>
                <input type="text" placeholder="Event Name" name="event_name">
                <label>Event Location</label>
                <input type="text" name="event_location">
                <label>Event Date</label>
                <input type="date" name="event_date">
                <label>Event Time</label>
                <input type="time"  name="event_time">
                <label>Confime Time</label>
                <select name="settime">
                    <option value="Am">Am</option>
                    <option value="Pm">Pm</option>

                </select>
                <label>Event Image</label>
                <input type="file" name="event_img">
                <label>Event Description</label>
                <textarea placeholder="Event Information" name="event_info" id="event_info"></textarea>
                <button>Save</button>
            </form>
            
        </div>
    </div>
 
<?php $__env->stopSection(); ?>

<?php $__env->startPush('custom-scripts'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/35.2.1/classic/ckeditor.js"></script>
<script src="<?php echo e(asset("js/ckeditor.js")); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views\admin\addeventform.blade.php ENDPATH**/ ?>