
<?php $__env->startPush('icon'); ?>
<link rel="stylesheet" href="<?php echo e(asset("css/indexcss.css")); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="gallerypage">
 
    <div class="gallery-holder">
      <?php $__empty_1 = true; $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="gallery-img">
       
        <img src="<?php echo e(asset('gallery/'.$g->image)); ?>" alt="<?php echo e($g->tltel); ?>"/>
        
        <div class="gallery-info">
         <h1> <?php echo e($g->title); ?></h1>
          
        </div>
      
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          
      <?php endif; ?>
    </div>
  
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views\frontend\ourgallery.blade.php ENDPATH**/ ?>