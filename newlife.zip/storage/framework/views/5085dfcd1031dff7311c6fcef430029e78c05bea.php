
<?php $__env->startPush('icon'); ?>
<link rel="stylesheet" href="<?php echo e(asset("css/indexcss.css")); ?>">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="contact-form-holder">
    <div class="contact-form" style="background-image: url(<?php echo e(asset("logo/logo.jpeg")); ?>)">
        <h1>Send us a message</h1>
    <form action="/sendmessage" method="POST">
        <?php echo csrf_field(); ?>
        <label>Name</label>
        <input type="text" name="name" placeholder="Please enter your name"/>
        <label>Email</label>
        <input type="email" name="email" placeholder="Please enter your Email"/>
        <label>Message type</label>
        <select name="inquiry">
            <option selected value="inquiry">Inquiry</option>
            <option value="donation">Donation</option>
            <option value="help people in my area">Help people in my area</option>
            <option value="other">Other</option>
        </select>
        <label>Message</label>
        <textarea rows="5" name="message" maxlength="300" ></textarea>
        <input type="submit" class="contact-form-submit" value="Send"/>
    </form>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views\frontend\contact_us.blade.php ENDPATH**/ ?>