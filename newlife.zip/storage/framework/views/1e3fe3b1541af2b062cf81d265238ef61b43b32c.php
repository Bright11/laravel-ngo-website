

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="admin--content-dashboard">
   
    <?php echo $__env->make('admin.adminsidbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="admin-main-content">
        <h1>hi admin</h1>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\newlife\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>