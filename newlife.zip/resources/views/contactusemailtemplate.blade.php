<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
</head>
<style>
.myemail{
    font-size: 14px;
    margin:0;
    color: black;
    padding: 0;
}
</style>
<body>
    <p class="myemail">Bright C Web is alway ready to help you!</p>
	<p class="myemail">We will get back to you as soon as possible!</p>
    <p class="myemail">
        {{$body}}
    </p>
</body>
</html>
