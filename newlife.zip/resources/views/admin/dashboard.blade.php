@extends('admin.admin')

@section('content')
@include('admin.adminheader')
<div class="admin--content-dashboard">

    @include('admin.adminsidbar')
    <div class="admin-main-content">
       <p>This website was built by Bright C Web Developer. At Bright C Web Developer, we build websites, software, and mobile
        applications of any kind. We also advise our clients to use our software according to the law. Bright C Web
        Developer will not be held accountable for any misuse of this software. For any information or inquiries, please
        call +233558602996.</p>
    </div>
</div>
@endsection
