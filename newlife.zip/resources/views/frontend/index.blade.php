@extends('frontend.master')
@push('icon')
<link rel="stylesheet" href="{{asset("css/indexcss.css")}}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link rel="stylesheet" href="{{asset("/owl/owl.carousel.min.css")}}">
<link rel="stylesheet" href="{{asset("/owl/owl.theme.default.min.css")}}">
<link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
@endpush
@section('content')
<section class="top-slider">
  <div class="mytopslide"data-aos="fade-down">
    @include('frontend.top_slider')
  </div>
</section>
<h1 class="causesh1">Our <u class="h1color">Causes</u></h1>
  <div class="ourcause-holder">

    <div class="ourcauses-content">
    <div class="ourcauses-content-holder">
        @forelse ($causestable as $ourc)
            <div class="our-cause-rows" data-aos="fade-up">
              <div class="cuasusimg">
                <img src="{{asset("causeimg/" .$ourc->image)}}" alt="{{$ourc->name}}"/>
              </div>
                <h1>{{$ourc->name}}</h1>

             <p>{!!Str::limit($ourc->description,50,$end="")!!}<a href='/details/{{$ourc->id}}' class='readmore'> Read More...</a></p>

            </div>
        @empty
        <h1>Not found</h1>
        @endforelse
    </div>
  </div>

  <section class="event-section">

<div class="event-details">
  <div class="newevent-holder" >
    <h4>Latest Event</h4>
  <div class="newevent"data-aos="flip-up"data-aos-delay="50">

      @forelse ($event as $e)
         <a href="/viewevent/{{$e->id}}" class="eventlink"data-aos="fade-up">
          <div class="newevents">
            <img src="{{asset('event/'.$e->event_img)}}" alt=""/>
            <div class="eventinfo">
              <p>{{$e->event_name}}</p>

              <div class="eventinfodate">
              <p>{{$e->event_date}}:&nbsp;{{$e->event_time}} {{$e->settime}}</p>

            </div>
          </div>

          </div>
         </a>
      @empty
      @endforelse
  </div>
</div>
  <div class="passevent">
    <h4>All enevts</h4>
    <div class="mywol-container">
      <div class="eventslid owl-carousel owl-theme" data-aos="fade-up">
        @forelse ($allevent as $e)
        <div class="owlitemindex" >

          <img src="{{asset('event/'.$e->event_img)}}" alt=""/>



            <div class="owlitemindex-details">
              <p>{{$e->event_name}}</p>

            <p>{{$e->event_date}} &nbsp;{{$e->event_time}} {{$e->settime}}</p>
          </div>

        </div>
    @empty
    @endforelse

    </div>
    </div>
  </div>

  <div class="donatindex-hplder-items"data-aos="fade-up">
    <h4 class="helph1">Your help will help to limit crime</h4>
    <div class="donet" style="background-image: url({{asset("logo/logo.jpeg")}})">
        {{-- <h4 class="helph1">Your help will help to limit crime</h4> --}}
        {{-- <form>
            <label>Name <small>Optional</small></label>
            <input type="text" placeholder="Your Name " />
            <label>Donate for</label>
            <input type="text" placeholder="Donating for" />
            <label>Amount</label>
            <input type="number" placeholder="Amount to Donate" />
            <button>Donate</button>
        </form> --}}
        <div class="index-donation">
            @include('frontend.pay')

        </div>
    </div>
  </div>

</div>
  </section>
  <section class="voluteers">

      <h3 >Our Gallery</h3>
    <div class="gallery-slide owl-carousel" data-aos="fade-up">
      @forelse ($getgallery as $s)
          <div class="mysponsor">

            <img src="{{asset('gallery/'.$s->image)}}" alt="{{$s->title}}"/>
            <div class="company-name">
           <h1 class="galleryh1"> {{$s->title}}</h1>
            </div>

          </div>
      @empty

      @endforelse

    </div>
   <div class="view-all-gallery">
    <a href="/ourgallery">View all gallery</a>
   </div>
    <h3 >Our Sponsors</h3>
    <div class="voluteers-slide owl-carousel"data-aos="fade-down" >
      @forelse ($sponsor as $s)
          <div class="mysponsor">
            <a href="{{$s->company_website}}">
            <img src="{{asset('sponsor/'.$s->company_logo)}}" alt="{{$s->company_name}}"/>
            <div class="company-name">
           <h1> {{$s->company_name}}</h1>
            </div>
          </a>
          </div>
      @empty

      @endforelse

    </div>

  </section>


  </div>
@endsection
@push('js')
<script src="{{asset("js/jquery.js")}}"></script>
<script src="{{asset("owl/owl.carousel.min.js")}}"></script>
<script src="{{asset("owl/myowl.js")}}"></script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script>
    AOS.init();
</script>
@endpush
