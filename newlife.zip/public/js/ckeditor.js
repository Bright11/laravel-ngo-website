ClassicEditor.create(document.querySelector("#event_info")).catch((error) => {
    console.error(error);
});

ClassicEditor.create(document.querySelector("#description")).catch((error) => {
    console.error(error);
});

ClassicEditor.create(document.querySelector("#about")).catch((error) => {
    console.error(error);
});

ClassicEditor.create(document.querySelector("#bloginfo")).catch((error) => {
    console.error(error);
});
